to build eclipse plug-in, java files of folder 'scr/com/sqldalmaker/netbeans' must be hidden in zip.

to build netbeans plug-in, these file must be unzipped back.