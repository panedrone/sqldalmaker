1) to build eclipse plug-in, 'scr/com/sqldalmaker/netbeans/*.java' must be renamed to *.jav_
2) to build/develop netbeans plug-in, 'scr/com/sqldalmaker/netbeans/*.jav_' must be renamed back to *.java